#include "MealRecommendation.h"
#include <iostream>

MealRecommendation::MealRecommendation() {

    mealDatabase["Vegan Salad"] = {"vegan", "gluten-free"};
    mealDatabase["Chicken Curry"] = {"non-vegetarian"};
    mealDatabase["Gluten-Free Pasta"] = {"vegetarian", "gluten-free"};
    mealDatabase["Fruit Smoothie"] = {"vegan", "gluten-free"};
}

bool MealRecommendation::isSuitableMeal(const std::string& meal, const UserPreferences& preferences) {
    const auto& tags = mealDatabase[meal];
    
    if (!preferences.diet.empty() && std::find(tags.begin(), tags.end(), preferences.diet) == tags.end()) {
        return false;
    }

    for (const auto& ingredient : preferences.dislikes) {
        if (meal.find(ingredient) != std::string::npos) {
            return false;
        }
    }
    
    return true;
}

std::vector<std::string> MealRecommendation::recommendMeals(const UserPreferences& preferences) {
    std::vector<std::string> suitableMeals;
    for (const auto& [meal, tags] : mealDatabase) {
        if (isSuitableMeal(meal, preferences)) {
            suitableMeals.push_back(meal);
        }
    }
    return suitableMeals;
}
