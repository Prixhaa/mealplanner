#ifndef USERAUTH_H
#define USERAUTH_H

#include <string>
#include <unordered_map>
using namespace std; 

class UserAuth {
public:
    bool registerUser(const std::string& username, const std::string& password);
    bool loginUser(const std::string& username, const std::string& password);

private:
    std::unordered_map<std::string, std::string> userDatabase;
};

#endif


bool UserAuth::registerUser(const std::string& username, const std::string& password) {
    if (userDatabase.find(username) != userDatabase.end()) {
        std::cout << "User already exists!\n";
        return false;
    }
    userDatabase[username] = password;
    std::cout << "User registered successfully!\n";
    return true;
}

bool UserAuth::loginUser(const std::string& username, const std::string& password) {
    if (userDatabase.find(username) != userDatabase.end() && userDatabase[username] == password) {
        std::cout << "Login successful!\n";
        return true;
    }
    std::cout << "Invalid username or password!\n";
    return false;
}