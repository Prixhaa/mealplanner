#ifndef MEALRECOMMENDATION_H
#define MEALRECOMMENDATION_H

#include <string>
#include <vector>
#include <unordered_map>

struct UserPreferences {
    std::string diet;  
    std::vector<std::string> dislikes;  
};

class MealRecommendation {
public:
    MealRecommendation();
    std::vector<std::string> recommendMeals(const UserPreferences& preferences);

private:
    std::unordered_map<std::string, std::vector<std::string>> mealDatabase;
    bool isSuitableMeal(const std::string& meal, const UserPreferences& preferences);
};

#endif
