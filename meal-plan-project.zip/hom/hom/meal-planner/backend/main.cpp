#include "crow_all.h"
#include "nlohmann/json.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <boost/asio.hpp>


using json = nlohmann::json;

struct Meal {
    std::string name;
    int calories;
    std::vector<std::string> ingredients;
    std::string dietaryType;  
};

std::vector<Meal> meals = {
    {"Quinoa Salad", 300, {"quinoa", "spinach", "tomatoes"}, "vegetarian"},
    {"Grilled Chicken", 500, {"chicken", "olive oil", "lemon"}, "non-vegetarian"},
    {"Fruit Smoothie", 200, {"banana", "berries", "yogurt"}, "vegan"},
    {"Vegan Burger", 450, {"black beans", "lettuce", "tomato"}, "vegan"},
    
};


std::vector<Meal> recommendMeals(const std::string& dietaryType, int maxCalories) {
    std::vector<Meal> recommendedMeals;
    for (const auto& meal : meals) {
        if (meal.dietaryType == dietaryType && meal.calories <= maxCalories) {
            recommendedMeals.push_back(meal);
        }
    }
    return recommendedMeals;
}

int main() {
    crow::SimpleApp app;

    
    CROW_ROUTE(app, "/recommend").methods("POST"_method)([](const crow::request& req) {
        auto reqData = json::parse(req.body);
        std::string dietaryType = reqData["dietaryType"];
        int maxCalories = reqData["maxCalories"];

        std::vector<Meal> recommendations = recommendMeals(dietaryType, maxCalories);

        json response;
        for (const auto& meal : recommendations) {
            response.push_back({
                {"name", meal.name},
                {"calories", meal.calories},
                {"ingredients", meal.ingredients},
                {"dietaryType", meal.dietaryType}
            });
        }

        return crow::response(response.dump());
    });

    
    app.port(8080).multithreaded().run();
}
